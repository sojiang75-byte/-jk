#include "quant/rate_limiter.hpp"
#include <algorithm>
#include <stdexcept>

namespace quant {
TokenBucket::TokenBucket(double capacity, double refill_per_second)
    : capacity_(capacity), tokens_(capacity), refill_per_second_(refill_per_second),
      last_(std::chrono::steady_clock::now()) {
    if (capacity <= 0.0 || refill_per_second < 0.0)
        throw std::invalid_argument("invalid token bucket configuration");
}
bool TokenBucket::try_acquire(double tokens) {
    if (tokens <= 0.0) return false;
    std::lock_guard<std::mutex> lock(mutex_);
    const auto now = std::chrono::steady_clock::now();
    const std::chrono::duration<double> elapsed = now - last_;
    tokens_ = std::min(capacity_, tokens_ + elapsed.count() * refill_per_second_);
    last_ = now;
    if (tokens_ < tokens) return false;
    tokens_ -= tokens;
    return true;
}
}
