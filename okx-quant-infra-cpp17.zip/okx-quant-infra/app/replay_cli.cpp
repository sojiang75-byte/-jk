#include "quant/replay.hpp"
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Usage: replay_cli <trades.jsonl>\n";
        return 2;
    }
    std::size_t count = 0;
    std::string error;
    const bool ok = quant::replay_jsonl(argv[1], [&](const quant::Trade& t) {
        ++count;
        std::cout << t.timestamp_ms << " " << t.symbol << " price=" << t.price
                  << " size=" << t.size << "\n";
    }, &error);
    if (!ok) { std::cerr << "Replay failed: " << error << "\n"; return 1; }
    std::cout << "Replayed " << count << " trades\n";
    return 0;
}
