#include "quant/risk_engine.hpp"
#include <cmath>
#include <limits>

namespace quant {
RiskResult RiskEngine::evaluate(const OrderIntent& order, const OrderBook& book,
                                std::uint64_t now_ms) const {
    RiskResult out;
    auto reject = [&](const std::string& reason) { out.reasons.push_back(reason); };
    if (!std::isfinite(order.quantity) || order.quantity <= 0.0) reject("quantity must be positive and finite");
    if (!std::isfinite(order.reference_price) || order.reference_price <= 0.0) reject("reference price must be positive and finite");
    if (order.quantity > config_.max_order_quantity) reject("maximum order quantity exceeded");
    if (order.quantity > 0.0 && order.reference_price > 0.0 &&
        order.quantity * order.reference_price > config_.max_order_notional)
        reject("maximum order notional exceeded");
    const auto t = book.ticker();
    if (!t) {
        reject("order book is empty");
    } else {
        if (now_ms < t->timestamp_ms || now_ms - t->timestamp_ms > config_.max_book_age_ms)
            reject("order book is stale or timestamp is in the future");
        out.estimated_slippage_bps = book.estimate_slippage_bps(order.side, order.quantity);
        if (!std::isfinite(out.estimated_slippage_bps)) reject("insufficient visible depth");
        else if (out.estimated_slippage_bps > config_.max_slippage_bps) reject("maximum slippage exceeded");
    }
    out.approved = out.reasons.empty();
    return out;
}
}
