#pragma once
#include "quant/order_book.hpp"
#include "quant/types.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace quant {
struct RiskConfig {
    double max_order_quantity{1.0};
    double max_order_notional{10000.0};
    double max_slippage_bps{20.0};
    std::uint64_t max_book_age_ms{2000};
};
struct OrderIntent {
    Side side{Side::Buy};
    double quantity{0.0};
    double reference_price{0.0};
};
struct RiskResult {
    bool approved{false};
    std::vector<std::string> reasons;
    double estimated_slippage_bps{0.0};
};
class RiskEngine {
public:
    explicit RiskEngine(RiskConfig config) : config_(config) {}
    RiskResult evaluate(const OrderIntent& order, const OrderBook& book,
                       std::uint64_t now_ms) const;
private:
    RiskConfig config_;
};
}
