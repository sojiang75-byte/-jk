#pragma once
#include "quant/types.hpp"
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace quant {
class OrderBook {
public:
    bool load_snapshot(const std::string& symbol,
                       const std::vector<Level>& bids,
                       const std::vector<Level>& asks,
                       std::uint64_t sequence,
                       std::uint64_t timestamp_ms);
    // Applies an absolute-quantity update. quantity == 0 removes the level.
    // Returns false for stale/out-of-order sequence numbers or invalid levels.
    bool apply_update(Side side, double price, double quantity,
                      std::uint64_t sequence, std::uint64_t timestamp_ms);
    std::optional<BookTicker> ticker() const;
    double estimate_slippage_bps(Side taker_side, double quantity) const;
    std::uint64_t timestamp_ms() const noexcept { return timestamp_ms_; }
    std::uint64_t sequence() const noexcept { return sequence_; }
    bool empty() const noexcept { return bids_.empty() || asks_.empty(); }
private:
    std::string symbol_;
    std::map<double, double, std::greater<double>> bids_;
    std::map<double, double> asks_;
    std::uint64_t sequence_{0};
    std::uint64_t timestamp_ms_{0};
};
}
