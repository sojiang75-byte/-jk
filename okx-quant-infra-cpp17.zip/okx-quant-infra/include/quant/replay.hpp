#pragma once
#include "quant/types.hpp"
#include <functional>
#include <string>

namespace quant {
// Reads JSONL trade records with fields type, symbol, price, size and ts_ms.
bool replay_jsonl(const std::string& path, const std::function<void(const Trade&)>& on_trade,
                  std::string* error = nullptr);
}
