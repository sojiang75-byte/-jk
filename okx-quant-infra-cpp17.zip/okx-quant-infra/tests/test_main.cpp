#include "quant/order_book.hpp"
#include "quant/risk_engine.hpp"
#include "quant/rate_limiter.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

int main() {
    quant::OrderBook book;
    assert(book.load_snapshot("BTC-USDT", {{99.0, 2.0}, {98.0, 3.0}},
                              {{100.0, 2.0}, {101.0, 3.0}}, 10, 1000));
    auto tick = book.ticker();
    assert(tick && tick->bid == 99.0 && tick->ask == 100.0);
    assert(!book.apply_update(quant::Side::Buy, 99.5, 1.0, 10, 1001));
    assert(book.apply_update(quant::Side::Buy, 99.5, 1.0, 11, 1001));
    assert(std::isfinite(book.estimate_slippage_bps(quant::Side::Buy, 1.0)));

    quant::RiskConfig cfg;
    cfg.max_order_quantity = 2.0;
    cfg.max_order_notional = 1000.0;
    cfg.max_slippage_bps = 100.0;
    cfg.max_book_age_ms = 500;
    quant::RiskEngine risk(cfg);
    auto ok = risk.evaluate({quant::Side::Buy, 1.0, 100.0}, book, 1100);
    assert(ok.approved);
    auto stale = risk.evaluate({quant::Side::Buy, 1.0, 100.0}, book, 2000);
    assert(!stale.approved);

    quant::TokenBucket bucket(2.0, 0.0);
    assert(bucket.try_acquire());
    assert(bucket.try_acquire());
    assert(!bucket.try_acquire());
    std::cout << "All tests passed\n";
}
