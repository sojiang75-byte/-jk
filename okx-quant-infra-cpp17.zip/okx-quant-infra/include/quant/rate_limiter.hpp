#pragma once
#include <chrono>
#include <mutex>

namespace quant {
class TokenBucket {
public:
    TokenBucket(double capacity, double refill_per_second);
    bool try_acquire(double tokens = 1.0);
private:
    double capacity_, tokens_, refill_per_second_;
    std::chrono::steady_clock::time_point last_;
    std::mutex mutex_;
};
}
