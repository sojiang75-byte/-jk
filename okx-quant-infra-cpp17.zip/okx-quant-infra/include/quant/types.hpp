#pragma once
#include <cstdint>
#include <string>

namespace quant {
struct Level {
    double price{0.0};
    double quantity{0.0};
};
struct BookTicker {
    std::string symbol;
    double bid{0.0};
    double ask{0.0};
    std::uint64_t timestamp_ms{0};
    std::uint64_t sequence{0};
};
struct Trade {
    std::string symbol;
    double price{0.0};
    double size{0.0};
    std::uint64_t timestamp_ms{0};
};
enum class Side { Buy, Sell };
}
