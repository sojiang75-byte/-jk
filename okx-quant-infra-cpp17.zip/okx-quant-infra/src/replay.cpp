#include "quant/replay.hpp"
#include <fstream>
#include <regex>

namespace quant {
bool replay_jsonl(const std::string& path, const std::function<void(const Trade&)>& cb,
                  std::string* error) {
    std::ifstream in(path);
    if (!in) { if (error) *error = "cannot open input file"; return false; }
    const std::regex pattern(
        R"json("type"\s*:\s*"trade".*"symbol"\s*:\s*"([^"]+)".*"price"\s*:\s*([0-9]+(?:\.[0-9]+)?).*"size"\s*:\s*([0-9]+(?:\.[0-9]+)?).*"ts_ms"\s*:\s*([0-9]+))json");
    std::string line;
    std::size_t line_no = 0;
    while (std::getline(in, line)) {
        ++line_no;
        if (line.empty()) continue;
        std::smatch m;
        if (!std::regex_search(line, m, pattern)) {
            if (error) *error = "invalid trade JSON on line " + std::to_string(line_no);
            return false;
        }
        cb(Trade{m[1].str(), std::stod(m[2].str()), std::stod(m[3].str()),
                 static_cast<std::uint64_t>(std::stoull(m[4].str()))});
    }
    return true;
}
}
