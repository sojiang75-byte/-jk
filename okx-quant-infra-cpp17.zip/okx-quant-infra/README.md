# OKX Quant Infrastructure (C++17)

A small, exchange-independent C++17 foundation for an OKX market-data and
risk-control project. This repository intentionally starts with deterministic
core components that can be built and tested without API credentials.

## Included

- L2 order book with snapshot loading and sequence-checked updates.
- Pre-trade risk checks for quantity, notional, book freshness and estimated
  market-order slippage.
- Token-bucket rate limiter.
- JSON Lines replay reader and a small replay CLI.
- Unit tests and a GitHub Actions build workflow.

## Not included yet

This starter does **not** connect to OKX WebSocket/REST, submit live orders,
manage credentials, or implement a profitable trading strategy. Those should
be added as separate, tested modules. Never put API keys or secret passphrases
in source control.

## Build

Requires CMake 3.16+ and a C++17 compiler.

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

## Replay input format

One JSON object per line. The current parser deliberately supports a small
schema without a third-party JSON dependency:

```json
{"type":"trade","symbol":"BTC-USDT","price":65000.0,"size":0.01,"ts_ms":1730000000000}
```

Run:

```bash
./build/replay_cli examples/trades.jsonl
```

## Safety

Risk limits are examples, not financial advice or a guarantee against loss.
Validate exchange precision, contract multipliers, fee models, tick sizes,
lot sizes, latency and market-data semantics before connecting execution.
