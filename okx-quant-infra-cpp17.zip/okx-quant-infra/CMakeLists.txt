cmake_minimum_required(VERSION 3.16)
project(okx_quant_infra VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(quant_core
    src/order_book.cpp
    src/risk_engine.cpp
    src/rate_limiter.cpp
    src/replay.cpp
)
target_include_directories(quant_core PUBLIC include)
if(MSVC)
  target_compile_options(quant_core PRIVATE /W4)
else()
  target_compile_options(quant_core PRIVATE -Wall -Wextra -Wpedantic)
endif()

add_executable(replay_cli app/replay_cli.cpp)
target_link_libraries(replay_cli PRIVATE quant_core)

enable_testing()
add_executable(quant_tests tests/test_main.cpp)
target_link_libraries(quant_tests PRIVATE quant_core)
add_test(NAME quant_tests COMMAND quant_tests)
