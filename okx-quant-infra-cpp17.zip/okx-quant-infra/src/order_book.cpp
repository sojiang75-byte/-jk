#include "quant/order_book.hpp"
#include <cmath>
#include <limits>

namespace quant {
namespace {
bool valid_levels(const std::vector<Level>& levels) {
    for (const auto& x : levels)
        if (!std::isfinite(x.price) || !std::isfinite(x.quantity) ||
            x.price <= 0.0 || x.quantity < 0.0) return false;
    return true;
}
}
bool OrderBook::load_snapshot(const std::string& symbol,
                              const std::vector<Level>& bids,
                              const std::vector<Level>& asks,
                              std::uint64_t sequence,
                              std::uint64_t timestamp_ms) {
    if (symbol.empty() || !valid_levels(bids) || !valid_levels(asks)) return false;
    std::map<double, double, std::greater<double>> new_bids;
    std::map<double, double> new_asks;
    for (const auto& x : bids) if (x.quantity > 0) new_bids[x.price] = x.quantity;
    for (const auto& x : asks) if (x.quantity > 0) new_asks[x.price] = x.quantity;
    if (new_bids.empty() || new_asks.empty() || new_bids.begin()->first >= new_asks.begin()->first)
        return false;
    symbol_ = symbol;
    bids_ = std::move(new_bids);
    asks_ = std::move(new_asks);
    sequence_ = sequence;
    timestamp_ms_ = timestamp_ms;
    return true;
}
bool OrderBook::apply_update(Side side, double price, double quantity,
                             std::uint64_t sequence, std::uint64_t timestamp_ms) {
    if (empty() || sequence <= sequence_ || !std::isfinite(price) ||
        !std::isfinite(quantity) || price <= 0.0 || quantity < 0.0) return false;
    if (side == Side::Buy) {
        if (quantity == 0.0) bids_.erase(price); else bids_[price] = quantity;
    } else {
        if (quantity == 0.0) asks_.erase(price); else asks_[price] = quantity;
    }
    if (bids_.empty() || asks_.empty() || bids_.begin()->first >= asks_.begin()->first)
        return false;
    sequence_ = sequence;
    timestamp_ms_ = timestamp_ms;
    return true;
}
std::optional<BookTicker> OrderBook::ticker() const {
    if (empty()) return std::nullopt;
    return BookTicker{symbol_, bids_.begin()->first, asks_.begin()->first,
                      timestamp_ms_, sequence_};
}
double OrderBook::estimate_slippage_bps(Side taker_side, double quantity) const {
    if (quantity <= 0.0 || empty()) return std::numeric_limits<double>::infinity();
    const double best = taker_side == Side::Buy ? asks_.begin()->first : bids_.begin()->first;
    double remaining = quantity, notional = 0.0, filled = 0.0;
    if (taker_side == Side::Buy) {
        for (const auto& [price, size] : asks_) {
            const double take = std::min(remaining, size);
            notional += take * price; filled += take; remaining -= take;
            if (remaining <= 1e-12) break;
        }
    } else {
        for (const auto& [price, size] : bids_) {
            const double take = std::min(remaining, size);
            notional += take * price; filled += take; remaining -= take;
            if (remaining <= 1e-12) break;
        }
    }
    if (remaining > 1e-12 || filled <= 0.0) return std::numeric_limits<double>::infinity();
    const double average = notional / filled;
    return std::abs(average - best) / best * 10000.0;
}
}
